package com.unmsm.ads.banking.ws.util;

public class Constantes {
	
	public static final String COD_RESPONSE_SUCCESS = "OK";
	public static final String DES_RESPONSE_SUCCESS = "The transfer was successful";
	public static final String COD_RESPONSE_ERROR = "FAIL";

}
